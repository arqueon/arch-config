flatpak install --system io.github.vikdevelop.SaveDesktop -y
