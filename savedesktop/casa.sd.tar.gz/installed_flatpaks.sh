flatpak install --system io.github.shiftey.Desktop -y
flatpak install --system io.github.vikdevelop.SaveDesktop -y
flatpak install --system io.typora.Typora -y
