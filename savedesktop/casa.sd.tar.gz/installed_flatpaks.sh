flatpak install --system io.github.vikdevelop.SaveDesktop -y
flatpak install --system md.obsidian.Obsidian -y
