# From feedback
* customizing look and feel with themes
* Optionally darken screen / some similar effect when showing the switcher
* Optionally search by non-localized name too

# Bugs

# Otherwise
* Activating with double modifier key (shift, alt, ctrl) if at all possible with JS only
